import type { Task, TaskCreate, TaskUpdate } from './types'

// Adjust base URL if backend runs elsewhere
const BASE = (import.meta as any).env?.VITE_API_URL || 'http://localhost:8000'

async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...init
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`${res.status} ${res.statusText} ${text}`)
  }
  return res.json() as Promise<T>
}

export async function listTasks(): Promise<Task[]> {
  return http<Task[]>('/tasks')
}

export async function createTask(payload: TaskCreate): Promise<Task> {
  return http<Task>('/tasks', {
    method: 'POST',
    body: JSON.stringify(payload)
  })
}

export async function updateTask(id: number, payload: TaskUpdate): Promise<Task> {
  return http<Task>(`/tasks/${id}`, {
    method: 'PUT',
    body: JSON.stringify(payload)
  })
}

export async function deleteTask(id: number): Promise<void> {
  const res = await fetch(`${BASE}/tasks/${id}`, { method: 'DELETE' })
  if (!res.ok && res.status !== 204) {
    const text = await res.text().catch(() => '')
    throw new Error(`${res.status} ${res.statusText} ${text}`)
  }
}
