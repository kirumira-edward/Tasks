import { useEffect, useMemo, useState } from 'react'
import './App.css'
import { createTask, deleteTask, listTasks, updateTask } from './api'
import type { Task } from './types'

export default function App() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTitle, setNewTitle] = useState('')
  const [filter, setFilter] = useState<'all' | 'open' | 'done'>('all')
  const [loading, setLoading] = useState(true)
  const [err, setErr] = useState<string | null>(null)

  useEffect(() => {
    let alive = true
    ;(async () => {
      try {
        const data = await listTasks()
        if (alive) setTasks(data)
      } catch (e:any) {
        setErr(e?.message ?? 'Failed to load')
      } finally {
        if (alive) setLoading(false)
      }
    })()
    return () => { alive = false }
  }, [])

  const filtered = useMemo(() => {
    if (filter === 'all') return tasks
    if (filter === 'open') return tasks.filter(t => !t.done)
    return tasks.filter(t => t.done)
  }, [tasks, filter])

  async function add() {
    const title = newTitle.trim()
    if (!title) return
    const optimistic: Task = { id: Math.max(0, ...tasks.map(t => t.id)) + 1, title, done: false }
    setTasks(prev => [...prev, optimistic])
    setNewTitle('')
    try {
      const created = await createTask({ title, done: false })
      setTasks(prev => prev.map(t => t === optimistic ? created : t))
    } catch (e) {
      setTasks(prev => prev.filter(t => t !== optimistic))
      alert('Failed to create task')
    }
  }

  async function toggle(t: Task) {
    const updated = { ...t, done: !t.done }
    setTasks(prev => prev.map(x => x.id === t.id ? updated : x))
    try {
      await updateTask(t.id, { done: updated.done })
    } catch {
      setTasks(prev => prev.map(x => x.id === t.id ? t : x))
      alert('Failed to update task')
    }
  }

  async function rename(t: Task, title: string) {
    const val = title.trim()
    if (!val || val === t.title) return
    const updated = { ...t, title: val }
    setTasks(prev => prev.map(x => x.id === t.id ? updated : x))
    try {
      await updateTask(t.id, { title: val })
    } catch {
      setTasks(prev => prev.map(x => x.id === t.id ? t : x))
      alert('Failed to rename task')
    }
  }

  async function remove(t: Task) {
    const prev = tasks
    setTasks(p => p.filter(x => x.id !== t.id))
    try {
      await deleteTask(t.id)
    } catch {
      setTasks(prev)
      alert('Failed to delete task')
    }
  }

  return (
    <div className="container">
      <h1>Task Manager Lite</h1>
      <p className="muted">FastAPI backend · React + Vite frontend</p>

      <div className="card">
        <div className="row">
          <input
            className="input"
            placeholder="New task..."
            value={newTitle}
            onChange={e => setNewTitle(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && add()}
          />
          <button className="btn" onClick={add}>Add</button>
        </div>
        <div className="row" style={{ marginTop: 10 }}>
          <button className={'btn ghost'} onClick={() => setFilter('all')}>All</button>
          <button className={'btn ghost'} onClick={() => setFilter('open')}>Open</button>
          <button className={'btn ghost'} onClick={() => setFilter('done')}>Done</button>
        </div>
      </div>

      <div className="list">
        {loading && <div className="muted">Loading…</div>}
        {err && <div className="muted">Error: {err}</div>}
        {!loading && filtered.map(t => (
          <Item
            key={t.id}
            task={t}
            onToggle={() => toggle(t)}
            onRename={(val) => rename(t, val)}
            onDelete={() => remove(t)}
          />
        ))}
      </div>
    </div>
  )
}

function Item({ task, onToggle, onRename, onDelete }:{
  task: Task,
  onToggle: () => void,
  onRename: (val: string) => void,
  onDelete: () => void
}) {
  const [title, setTitle] = useState(task.title)

  useEffect(() => setTitle(task.title), [task.title])

  return (
    <div className="item">
      <input
        type="checkbox"
        checked={task.done}
        onChange={onToggle}
        aria-label={`toggle-${task.id}`}
      />
      <input
        type="text"
        value={title}
        onChange={e => setTitle(e.target.value)}
        onBlur={() => onRename(title)}
        onKeyDown={e => e.key === 'Enter' && (e.currentTarget.blur())}
        style={{ textDecoration: task.done ? 'line-through' : 'none' }}
        aria-label={`title-${task.id}`}
      />
      <button className="btn ghost" onClick={onDelete}>Delete</button>
    </div>
  )
}
