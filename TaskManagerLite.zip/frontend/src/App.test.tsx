import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import App from './App'
import * as api from './api'

describe('App', () => {
  beforeEach(() => {
    vi.restoreAllMocks()
  })

  it('lists tasks, adds a task, toggles and deletes', async () => {
    const list = vi.spyOn(api, 'listTasks').mockResolvedValue([
      { id: 1, title: 'Existing', done: false }
    ])
    const create = vi.spyOn(api, 'createTask').mockImplementation(async (t) => ({ id: 2, ...t }))
    const update = vi.spyOn(api, 'updateTask').mockImplementation(async (id, p) => ({ id, title: 'Existing', done: !!p.done }))
    const remove = vi.spyOn(api, 'deleteTask').mockResolvedValue(undefined)

    render(<App />)

    // existing appears
    expect(await screen.findByDisplayValue('Existing')).toBeInTheDocument()
    expect(list).toHaveBeenCalled()

    // add
    const input = screen.getByPlaceholderText('New task...')
    fireEvent.change(input, { target: { value: 'New Task' } })
    fireEvent.click(screen.getByText('Add'))
    await waitFor(() => expect(create).toHaveBeenCalled())
    expect(await screen.findByDisplayValue('New Task')).toBeInTheDocument()

    // toggle
    const checkbox = screen.getAllByRole('checkbox')[0]
    fireEvent.click(checkbox)
    await waitFor(() => expect(update).toHaveBeenCalled())

    // delete
    const delButtons = screen.getAllByText('Delete')
    fireEvent.click(delButtons[0])
    await waitFor(() => expect(remove).toHaveBeenCalled())
  })
})
