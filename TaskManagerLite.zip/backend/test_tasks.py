import os
import asyncio
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

import main


@pytest.fixture(autouse=True, scope="module")
def set_test_db(monkeypatch):
    # use a file-based test DB to persist across requests in module
    test_url = "sqlite+aiosqlite:///./test_tasks.db"
    engine = create_async_engine(test_url, future=True, echo=False)
    TestingSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    # monkeypatch the app's engine/session to point to test DB
    monkeypatch.setattr(main, "engine", engine)
    monkeypatch.setattr(main, "AsyncSessionLocal", TestingSessionLocal)

    # create tables
    async def init():
        async with engine.begin() as conn:
            await conn.run_sync(main.Base.metadata.create_all)
    asyncio.get_event_loop().run_until_complete(init())

    yield

    # cleanup
    os.remove("./test_tasks.db")


@pytest.mark.asyncio
async def test_crud_flow():
    async with AsyncClient(app=main.app, base_url="http://test") as ac:
        # list empty
        resp = await ac.get("/tasks")
        assert resp.status_code == 200
        assert resp.json() == []

        # create
        resp = await ac.post("/tasks", json={"title": "First Task", "done": False})
        assert resp.status_code == 201
        t1 = resp.json()
        assert t1["title"] == "First Task"
        assert t1["done"] is False
        assert "id" in t1

        # get list has 1
        resp = await ac.get("/tasks")
        assert resp.status_code == 200
        tasks = resp.json()
        assert len(tasks) == 1
        assert tasks[0]["title"] == "First Task"

        # update title
        resp = await ac.put(f"/tasks/{t1['id']}", json={"title": "Renamed"})
        assert resp.status_code == 200
        t1u = resp.json()
        assert t1u["title"] == "Renamed"
        assert t1u["done"] is False

        # mark done
        resp = await ac.put(f"/tasks/{t1['id']}", json={"done": True})
        assert resp.status_code == 200
        t1u2 = resp.json()
        assert t1u2["done"] is True

        # delete
        resp = await ac.delete(f"/tasks/{t1['id']}")
        assert resp.status_code == 204

        # not found on delete again
        resp = await ac.delete(f"/tasks/{t1['id']}")
        assert resp.status_code == 404

        # empty again
        resp = await ac.get("/tasks")
        assert resp.status_code == 200
        assert resp.json() == []
