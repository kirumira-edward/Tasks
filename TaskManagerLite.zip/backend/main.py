from __future__ import annotations
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import Column, Integer, String, Boolean, select
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import declarative_base, sessionmaker

# --- DB setup (SQLite, async) ---
DATABASE_URL = "sqlite+aiosqlite:///./tasks.db"
engine = create_async_engine(DATABASE_URL, future=True, echo=False)
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
Base = declarative_base()


class TaskORM(Base):
    __tablename__ = "tasks"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    done = Column(Boolean, default=False, nullable=False)


class TaskIn(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    done: bool = False


class TaskUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=1, max_length=255)
    done: Optional[bool] = None


class TaskOut(BaseModel):
    id: int
    title: str
    done: bool

    class Config:
        from_attributes = True


app = FastAPI(title="Task Manager Lite")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def on_startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


# --- Routes ---
@app.get("/tasks", response_model=List[TaskOut])
async def list_tasks():
    async with AsyncSessionLocal() as session:
        res = await session.execute(select(TaskORM).order_by(TaskORM.id))
        rows = res.scalars().all()
        return [TaskOut.model_validate(r) for r in rows]


@app.post("/tasks", response_model=TaskOut, status_code=201)
async def create_task(payload: TaskIn):
    async with AsyncSessionLocal() as session:
        task = TaskORM(title=payload.title, done=payload.done)
        session.add(task)
        await session.commit()
        await session.refresh(task)
        return TaskOut.model_validate(task)


@app.put("/tasks/{task_id}", response_model=TaskOut)
async def update_task(task_id: int, payload: TaskUpdate):
    async with AsyncSessionLocal() as session:
        res = await session.execute(select(TaskORM).where(TaskORM.id == task_id))
        task = res.scalar_one_or_none()
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")

        if payload.title is not None:
            task.title = payload.title
        if payload.done is not None:
            task.done = payload.done

        await session.commit()
        await session.refresh(task)
        return TaskOut.model_validate(task)


@app.delete("/tasks/{task_id}", status_code=204)
async def delete_task(task_id: int):
    async with AsyncSessionLocal() as session:
        res = await session.execute(select(TaskORM).where(TaskORM.id == task_id))
        task = res.scalar_one_or_none()
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        await session.delete(task)
        await session.commit()
        return


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
